document.querySelector("#button1").addEventListener("click" , function(){
    document.querySelector("#box").style.height = "250px";
} );

document.querySelector("#button2").addEventListener("click" , function(){
    document.querySelector("#box").style.background = "blue";
} );

document.querySelector("#button3").addEventListener("click" , function() {
    document.querySelector("#box").style.opacity = "0.4";
});

document.querySelector("#button4").addEventListener("click" , function(){
   document.querySelector("#box").style.height = "150px";
   document.querySelector("#box").style.background = "orange";
});

document.querySelector("#button5").addEventListener("click" , function(){
    document.querySelector("#box").style.background = "yellow";
});